<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="POST">
        Enter Year:
        <input type="text" name="textyear"/>
        <input type="submit" name="submit" value="Check Now"/>

    </form>
    <p>
        <?php
            if(isset($_POST['textyear'])){
                $LeapYear = $_POST['textyear'];
                 //echo $LeapYear;
                if(($LeapYear %4== 0) && ($LeapYear % 100 !=0) || ($LeapYear %  400 ==  0) ){
                    echo $LeapYear. "is  Leap Year";
                }else{
                    echo $LeapYear. "is not Leap Year";
                } 
            }
        ?>
    </p>
</body>
</html>



