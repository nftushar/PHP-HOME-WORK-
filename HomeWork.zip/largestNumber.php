<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LargestNumber</title>
</head>
<body>


<form action="" method="POST">
<br> <br>
        Enter A:
        <input type="text" name="a"/> <br><br>

        Enter B:
        <input type="text" name="b"/> <br><br>

        Enter C:
        <input type="text" name="c"/> 
       
        <input type="submit" name="submit" value="Check Now"/>
</form>



<?php
// $a = 22;
// $b = 33;
// $c = 404;

if ( isset( $_REQUEST['a'] ) && isset( $_REQUEST['b'] ) && isset( $_REQUEST['c'] ) ) {

    $a = $_REQUEST['a'];
    $b = $_REQUEST['b'];
    $c = $_REQUEST['c'];

        if($a>$b){
            if($a>$c){
                echo "A is largest & Number is",$a;
            }
            else{
                echo "C is largest & Number is",$c;
            }
        }

        if($b>$a){
            if($b>$c){
                echo "B is largest & Number is",$b;
            }
            else{
                echo "C is largest & Number is",$c;
            }
        }

        if($c>$a){
            if($c>$b){
                echo "C is largest & Number is",$c;
            }
            else{
                echo "B is largest & Number is",$b;
            }
        }


} 



?>


</body>
</html>