<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Triangle</title>
</head>
<body>
<form action="" method="POST">
      <br> <br>
        Enter Height:
        <input type="text" name="height"/> <br><br>

        Enter Base:
        <input type="text" name="base"/> <br><br>

        <input type="submit" name="submit" value="Check Now"/>
</form>

<?php
                 //AreaOFtriangle
 
// $height = 22;
//  $base   = 33;

if (isset( $_REQUEST['height'] ) && isset( $_REQUEST['base'] )) {

    $height = $_REQUEST['height'];
    $base = $_REQUEST['base'];
    
$areaOFtriangle = (1/2)*$height*$base;

echo $areaOFtriangle;

}


                            //AreaOFcircale
// $pi = 3.141;

// $rad = 5;

// $areaofcircle = $pi*$rad*$rad;

// echo $areaofcircle;

                
?>


</body>
</html>