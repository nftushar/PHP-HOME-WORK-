<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>

<div class="container">

    <div class="row">
 
        <form action="" method="POST">
          <label for="fnumber">Input a Year</label>
          <input type="number" name="number" id="number" required />
          <button type="submit">Submit</button>
        </form>

        <?php

            if ( isset( $_REQUEST['number'] ) ) {
                $n = $_REQUEST['number'];
                for ( $i = $n, $factorial = 1; $i > 0; $i-- ) {
                    $factorial = $factorial * $i;

                    echo "The factorial is", $factorial;
                }
            }

        ?>
   
    </div>
  </div>



</body>
</html>